
# numpygraph ![badge](https://github.com/turinggraph/numpygraph/workflows/test/badge.svg)
imploement graph deep and normal algorithm base on numpy

